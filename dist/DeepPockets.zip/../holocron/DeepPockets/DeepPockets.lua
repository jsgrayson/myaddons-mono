-- DeepPockets.lua
local addonName, addon = ...
DeepPocketsDB = DeepPocketsDB or {}

-- Constants
local TILE_SIZE = 37
local PADDING = 5
local COLS = 10

-- UI Elements
addon.Frame = nil
addon.ScrollFrame = nil
addon.Grid = nil
addon.ItemButtons = {}
addon.Tabs = {}

-- Data
addon.BagItems = {}
addon.BankItems = {}
addon.WarbandItems = {}
addon.Sections = {}
addon.CurrentTab = "BAGS" -- BAGS, BANK, WARBAND

-- Event Frame
local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("BAG_UPDATE")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("BANKFRAME_OPENED")
f:RegisterEvent("BANKFRAME_CLOSED")
f:RegisterEvent("PLAYERBANKSLOTS_CHANGED")
f:RegisterEvent("ZONE_CHANGED_NEW_AREA")
f:RegisterEvent("MERCHANT_SHOW")
f:RegisterEvent("AUCTION_HOUSE_SHOW")
f:RegisterEvent("MERCHANT_CLOSED")
f:RegisterEvent("AUCTION_HOUSE_CLOSED")

-- Context Logic
addon.FilterMode = "ALL"

f:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" and ... == addonName then
        addon:InitUI()
        print("|cff00ff00DeepPockets|r Loaded. Premium Bag Interface Active.")
    elseif event == "BAG_UPDATE" or event == "PLAYER_ENTERING_WORLD" then
        if addon.Frame and addon.Frame:IsShown() then
            addon:ScanBags()
            if addon.CurrentTab == "BAGS" then addon:RenderGrid() end
        end
    elseif event == "BANKFRAME_OPENED" then
        addon.Frame:Show()
        addon:SetTab("BANK")
    elseif event == "BANKFRAME_CLOSED" then
        addon:SetTab("BAGS")
    elseif event == "PLAYERBANKSLOTS_CHANGED" then
        if addon.CurrentTab == "BANK" then
            addon:ScanBank()
            addon:RenderGrid()
        end
    -- Context Events
    elseif event == "ZONE_CHANGED_NEW_AREA" then
        addon:CheckContext()
    elseif event == "MERCHANT_SHOW" then
        addon.FilterMode = "VENDOR"
        addon:RenderGrid()
    elseif event == "AUCTION_HOUSE_SHOW" then
        addon.FilterMode = "AH"
        addon:RenderGrid()
    elseif event == "MERCHANT_CLOSED" or event == "AUCTION_HOUSE_CLOSED" then
        addon:CheckContext() -- Revert to zone-based context
    end
end)

function addon:CheckContext()
    local _, instanceType = IsInInstance()
    if instanceType == "raid" or instanceType == "party" then
        addon.FilterMode = "RAID"
    else
        addon.FilterMode = "ALL"
    end
    addon:RenderGrid()
end

function addon:InitUI()
    -- Main Frame
    local f = CreateFrame("Frame", "DeepPocketsFrame", UIParent, "BackdropTemplate")
    f:SetSize(450, 550) -- Increased height for tabs
    f:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -50, 50)
    f:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    })
    f:SetBackdropColor(0, 0, 0, 0.9)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:Hide()
    
    -- Title
    f.Title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    f.Title:SetPoint("TOPLEFT", 10, -10)
    f.Title:SetText("DeepPockets")
    
    -- Close Button
    f.Close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    f.Close:SetPoint("TOPRIGHT", -5, -5)
    
    -- Search Box
    f.Search = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
    f.Search:SetSize(150, 20)
    f.Search:SetPoint("TOPRIGHT", -30, -10)
    f.Search:SetAutoFocus(false)
    f.Search:SetScript("OnTextChanged", function(self)
        addon:RenderGrid() -- Re-render on search
    end)
    
    -- Tabs
    local function CreateTab(id, text, x)
        local tab = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
        tab:SetSize(80, 25)
        tab:SetPoint("TOPLEFT", x, -35)
        tab:SetText(text)
        tab:SetScript("OnClick", function() addon:SetTab(id) end)
        return tab
    end
    
    addon.Tabs["BAGS"] = CreateTab("BAGS", "Bags", 10)
    addon.Tabs["BANK"] = CreateTab("BANK", "Bank", 95)
    addon.Tabs["WARBAND"] = CreateTab("WARBAND", "Warband", 180)
    
    -- Scroll Frame
    local sf = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT", 10, -70) -- Moved down for tabs
    sf:SetPoint("BOTTOMRIGHT", -30, 40)
    
    -- Content Frame (The Grid)
    local content = CreateFrame("Frame")
    content:SetSize(400, 800) -- Dynamic height later
    sf:SetScrollChild(content)
    addon.Grid = content
    addon.ScrollFrame = sf
    addon.Frame = f
    
    -- Footer: Incinerator Button
    local burnBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    burnBtn:SetSize(100, 25)
    burnBtn:SetPoint("BOTTOMLEFT", 10, 10)
    burnBtn:SetText("Burn Trash")
    burnBtn:SetScript("OnClick", function()
        print("|cffff0000DeepPockets|r: Incinerator not yet linked to server.")
    end)
    
    -- Hooks
    hooksecurefunc("OpenAllBags", function() f:Show(); addon:ScanBags(); addon:RenderGrid() end)
    hooksecurefunc("CloseAllBags", function() f:Hide() end)
    hooksecurefunc("ToggleAllBags", function() 
        if f:IsShown() then f:Hide() else f:Show(); addon:ScanBags(); addon:RenderGrid() end 
    end)
    
    addon:SetTab("BAGS")
end

function addon:SetTab(tabId)
    addon.CurrentTab = tabId
    
    -- Update Tab Visuals
    for id, btn in pairs(addon.Tabs) do
        if id == tabId then
            btn:Disable() -- Selected
        else
            btn:Enable()
        end
    end
    
    -- Scan if needed
    if tabId == "BANK" then addon:ScanBank()
    elseif tabId == "WARBAND" then addon:ScanWarband()
    else addon:ScanBags() end
    
    addon:RenderGrid()
end

function addon:ScanBags()
    addon.BagItems = {}
    addon:ScanContainerRange(0, 4, addon.BagItems)
    addon:SortItems(addon.BagItems)
end

function addon:ScanBank()
    addon.BankItems = {}
    -- Bank (-1)
    addon:ScanContainerRange(-1, -1, addon.BankItems)
    -- Reagent Bank (-3)
    addon:ScanContainerRange(-3, -3, addon.BankItems)
    -- Bank Bags (5-11)
    addon:ScanContainerRange(5, 11, addon.BankItems)
    addon:SortItems(addon.BankItems)
end

function addon:ScanWarband()
    addon.WarbandItems = {}
    -- Warband Bank (13-17 usually, but let's be safe and check availability)
    -- Assuming 5 tabs for now
    addon:ScanContainerRange(13, 17, addon.WarbandItems)
    addon:SortItems(addon.WarbandItems)
end

function addon:ScanContainerRange(startID, endID, targetTable)
    for bag = startID, endID do
        -- Check if bag exists (for bank bags)
        local slots = C_Container.GetContainerNumSlots(bag)
        if slots > 0 then
            for slot = 1, slots do
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if info then
                    local itemLink = info.hyperlink
                    local _, _, quality, _, _, class, subclass = GetItemInfo(itemLink)
                    
                    table.insert(targetTable, {
                        bag = bag,
                        slot = slot,
                        texture = info.iconFileID,
                        count = info.stackCount,
                        quality = quality or 1,
                        link = itemLink,
                        class = class or "Other",
                        subclass = subclass or "Other"
                    })
                end
            end
        end
    end
end

function addon:SortItems(itemTable)
    table.sort(itemTable, function(a, b)
        if a.quality ~= b.quality then
            return a.quality > b.quality
        end
        return (a.link or "") < (b.link or "")
    end)
end

function addon:RenderGrid()
    -- Select Data Source
    local dataSource = addon.BagItems
    if addon.CurrentTab == "BANK" then dataSource = addon.BankItems
    elseif addon.CurrentTab == "WARBAND" then dataSource = addon.WarbandItems end

    -- Hide all existing buttons
    for _, btn in pairs(addon.ItemButtons) do
        btn:Hide()
    end
    -- Hide all headers
    if not addon.Headers then addon.Headers = {} end
    for _, header in pairs(addon.Headers) do header:Hide() end
    
    local query = addon.Frame.Search:GetText():lower()
    
    -- Categorize
    local sections = {} 
    local sectionOrder = {"Consumable", "Weapon", "Armor", "Trade Goods", "Quest", "Junk", "Other"}
    
    -- Contextual Filters
    -- Define what categories are visible in each mode
    local VISIBILITY_RULES = {
        ["ALL"] = nil, -- Show everything
        ["RAID"] = { ["Consumable"] = true, ["Weapon"] = true, ["Armor"] = true },
        ["AH"] = { ["Trade Goods"] = true, ["Weapon"] = true, ["Armor"] = true, ["Recipe"] = true },
        ["VENDOR"] = { ["Junk"] = true, ["Quest"] = false } -- Highlight junk, hide quest?
    }
    
    -- Determine active filter
    -- Note: FILTER_MODE is local at top of file, we need to ensure it's accessible or stored in addon
    -- Let's assume we moved FILTER_MODE to addon.FilterMode in a previous step or we use the local one if scope permits.
    -- Since I replaced the whole file previously, FILTER_MODE was removed/reset. 
    -- I need to re-introduce the context tracking logic properly.
    
    local currentRules = VISIBILITY_RULES[addon.FilterMode or "ALL"]
    
    for _, item in ipairs(dataSource) do
        local name = GetItemInfo(item.link) or ""
        local matchesQuery = (query == "") or name:lower():find(query)
        
        if matchesQuery then
            local cat = item.class
            -- Map specific classes to our sections
            if item.quality == 0 then cat = "Junk"
            elseif item.class == "Quest" then cat = "Quest"
            elseif item.class == "Trade Goods" then cat = "Trade Goods"
            elseif item.class == "Consumable" then cat = "Consumable"
            elseif item.class == "Weapon" then cat = "Weapon"
            elseif item.class == "Armor" then cat = "Armor"
            else cat = "Other" end
            
            -- Apply Context Filter
            local isVisible = true
            if currentRules then
                -- If rule exists, it must be true. If rule is nil, show it? 
                -- Or strict whitelist? Let's do strict whitelist for RAID/AH.
                if addon.FilterMode == "VENDOR" then
                    -- Vendor mode: Show everything, but maybe sort Junk to top?
                    -- For now, just show all.
                    isVisible = true
                else
                    isVisible = currentRules[cat]
                end
            end
            
            if isVisible then
                if not sections[cat] then sections[cat] = {} end
                table.insert(sections[cat], item)
            end
        end
    end
    
    -- Render Sections
    local yOffset = 10
    local headerIdx = 1
    local btnIdx = 1
    
    for _, catName in ipairs(sectionOrder) do
        local items = sections[catName]
        if items and #items > 0 then
            -- Create/Reuse Header
            local header = addon.Headers[headerIdx]
            if not header then
                header = addon.Grid:CreateFontString(nil, "OVERLAY", "GameFontNormal")
                header:SetJustifyH("LEFT")
                addon.Headers[headerIdx] = header
            end
            header:SetText(catName)
            header:SetPoint("TOPLEFT", 5, -yOffset)
            header:Show()
            headerIdx = headerIdx + 1
            
            yOffset = yOffset + 20 -- Header height
            
            local col, row = 0, 0
            
            for _, item in ipairs(items) do
                local btn = addon.ItemButtons[btnIdx]
                if not btn then
                    btn = CreateFrame("Button", nil, addon.Grid, "ItemButtonTemplate")
                    btn:SetSize(TILE_SIZE, TILE_SIZE)
                    addon.ItemButtons[btnIdx] = btn
                end
                
                btn:SetID(item.slot)
                -- Clickable functionality
                SetItemButtonTexture(btn, item.texture)
                SetItemButtonCount(btn, item.count)
                SetItemButtonQuality(btn, item.quality, item.link)
                
                -- Position
                local x = col * (TILE_SIZE + PADDING)
                local y = -yOffset - (row * (TILE_SIZE + PADDING))
                btn:SetPoint("TOPLEFT", x, y)
                btn:Show()
                
                -- Glow if new (Mock logic: if quality > 3)
                if item.quality >= 4 then
                    ActionButton_ShowOverlayGlow(btn)
                else
                    ActionButton_HideOverlayGlow(btn)
                end
                
                col = col + 1
                if col >= COLS then
                    col = 0
                    row = row + 1
                end
                btnIdx = btnIdx + 1
            end
            
            -- Move Y down for next section
            if col > 0 then row = row + 1 end
            yOffset = yOffset + (row * (TILE_SIZE + PADDING)) + 10
        end
    end
    
    addon.Grid:SetHeight(yOffset + 50)
end

