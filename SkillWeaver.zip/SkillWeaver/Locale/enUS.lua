SkillWeaverL = {
  ADDON_NAME = "SkillWeaver",
  READY = "SkillWeaver ready.",
  PROFILE = "Profile",
  MODE = "Mode",
  TOGGLES = "Toggles",
  OPEN = "Open",
  RELOAD = "Reload UI",
}
