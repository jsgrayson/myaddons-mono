SkillWeaver = SkillWeaver or {}
local SW = SkillWeaver

SW.EnemyCount = SW.EnemyCount or {}

function SW.EnemyCount:Get()
  local plates = C_NamePlate and C_NamePlate.GetNamePlates and C_NamePlate.GetNamePlates()
  if not plates then return 1 end

  local count = 0
  for _, plate in ipairs(plates) do
    local unit = plate.namePlateUnitToken
    if unit and UnitCanAttack("player", unit) and not UnitIsDead(unit) then
      count = count + 1
    end
  end

  if count < 1 then count = 1 end
  return count
end
