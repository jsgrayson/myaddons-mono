-- Placeholder specific styles or constants if needed
local SW = SkillWeaver
SW.UI = SW.UI or {}
SW.UI.Style = {}
-- Example: SW.UI.Style.Font = "GameFontNormal"
