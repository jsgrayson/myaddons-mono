local SW = SkillWeaver
SW.UI = SW.UI or {}

local menuFrame

local function toggleValue(path)
  local t = SkillWeaverDB.toggles
  t[path] = not t[path]
  SW.Engine:RefreshAll("toggle_changed")
end

function SW.UI:ToggleMenu(anchor)
  if not menuFrame then
    menuFrame = CreateFrame("Frame", "SkillWeaver_Dropdown", UIParent, "UIDropDownMenuTemplate")
  end

  local key = SW.State:GetClassSpecKey()
  local mode = SW.State:GetMode()
  local profile = SW.Profiles:GetActiveProfileName(key)

  local function init()
    local info = UIDropDownMenu_CreateInfo()

    info.isTitle = true
    info.text = "SkillWeaver"
    info.notCheckable = true
    UIDropDownMenu_AddButton(info)

    info = UIDropDownMenu_CreateInfo()
    info.text = "Mode: " .. mode
    info.notCheckable = true
    UIDropDownMenu_AddButton(info)

    local modes = { "Delves", "MythicPlus", "Raid", "PvP", "OpenWorld" }
    if SkillWeaverBackend and SkillWeaverBackend:SupportsMidnight() then
      table.insert(modes, "Midnight")
    end

    for _, m in ipairs(modes) do
      info = UIDropDownMenu_CreateInfo()
      info.text = "Set Mode: " .. m
      info.notCheckable = true
      info.func = function() SW.State:SetMode(m) end
      UIDropDownMenu_AddButton(info)
    end

    info = UIDropDownMenu_CreateInfo()
    info.text = "Profile: " .. profile
    info.notCheckable = true
    UIDropDownMenu_AddButton(info)

    local profiles = { "Balanced", "HighPerformance", "Safe" }
    for _, p in ipairs(profiles) do
      info = UIDropDownMenu_CreateInfo()
      info.text = "Set Profile: " .. p
      info.notCheckable = true
      info.func = function() SW.Profiles:SetActiveProfileName(key, p) end
      UIDropDownMenu_AddButton(info)
    end

    info = UIDropDownMenu_CreateInfo()
    info.isTitle = true
    info.text = "Toggles"
    info.notCheckable = true
    UIDropDownMenu_AddButton(info)

    local toggles = {
      { k="burst", text="Burst" },
      { k="defensives", text="Defensives" },
      { k="interrupts", text="Interrupts" },
      { k="useTrinkets", text="Use Trinkets" },
      { k="dpsEmergencyHeals", text="DPS Emergency Heals" },
      { k="showHealButton", text="Show HEAL Button" },
      { k="showSelfButton", text="Show SELF Button" },
      { k="hideEmptyButtons", text="Hide Empty Buttons" },
      { k="smartPrimary", text="Smart Primary (Auto ST/AOE)" },
      -- Threshold is a slider usually, but here just a toggle isn't enough. 
      -- User asked to add both to minimap toggle menu. 
      -- For a threshold number, a toggle doesn't work well. 
      -- I'll just add the boolean toggle first. 
      -- Wait, "toggles.aoeThreshold = 3". This is a number. 
      -- The current menu implementation only supports booleans in the `toggles` loop.
      -- I will add a separate entry logic for the threshold or just leave it hardcoded / non-configurable in this simple menu for now?
      -- User said: "Add both to minimap toggle menu too."
      -- I should probably add a specialized button for Threshold +/-, or just 3 toggle options "AOE @ 3", "AOE @ 4".
      -- Or just rely on the boolean toggle and keep threshold fixed in this menu for now to avoid complexity, 
      -- BUT the request was explicit.
      -- Let's stick to the boolean toggle request for "smartPrimary". 
      -- For "aoeThreshold", I will create a submenu or dedicated buttons if I can.
      -- Actually, looking at the code, it iterates `toggles` and does `not SkillWeaverDB.toggles[t.k]`. 
      -- This flips booleans. Indexing a number would break it (3 -> false -> true).
      -- So I'll only add "smartPrimary" to the loop. 
      -- I will add a custom entry for AOE Threshold below the loop.
    }

    for _, t in ipairs(toggles) do
      info = UIDropDownMenu_CreateInfo()
      info.text = t.text
      info.checked = SkillWeaverDB.toggles[t.k]
      info.func = function()
        SkillWeaverDB.toggles[t.k] = not SkillWeaverDB.toggles[t.k]
        SW.Engine:RefreshAll("toggle_" .. t.k)
      end
      UIDropDownMenu_AddButton(info)
    end



    -- AOE Threshold Config (Per-Spec)
    info = UIDropDownMenu_CreateInfo()
    info.isTitle, info.notCheckable = true, true
    info.text = "Smart Primary Threshold (This Spec)"
    UIDropDownMenu_AddButton(info)

    SkillWeaverDB.specOverrides = SkillWeaverDB.specOverrides or {}
    SkillWeaverDB.specOverrides[key] = SkillWeaverDB.specOverrides[key] or {}

    local function setSpecThresh(v)
      SkillWeaverDB.specOverrides[key].aoeThreshold = v
      SW.Engine:RefreshAll("spec_thresh")
    end

    -- Values 2,3,4,5
    for _, v in ipairs({2,3,4,5}) do
      info = UIDropDownMenu_CreateInfo()
      info.text = tostring(v)
      info.checked = (tonumber(SkillWeaverDB.specOverrides[key].aoeThreshold) == v)
      info.func = function() setSpecThresh(v) end
      UIDropDownMenu_AddButton(info)
    end

    -- Reset to Default
    info = UIDropDownMenu_CreateInfo()
    info.text = "Use Spec Default"
    info.notCheckable = true
    info.func = function()
      SkillWeaverDB.specOverrides[key].aoeThreshold = nil
      SW.Engine:RefreshAll("spec_thresh_reset")
    end
    UIDropDownMenu_AddButton(info)

    -- Ground Target Mode Submenu
    info = UIDropDownMenu_CreateInfo()
    info.isTitle, info.notCheckable = true, true
    info.text = "Ground Target Mode"
    UIDropDownMenu_AddButton(info)

    for _, v in ipairs({ "cursor", "player" }) do
      info = UIDropDownMenu_CreateInfo()
      info.text = (v == "cursor") and "@cursor (fast)" or "@player (safe)"
      info.checked = (SkillWeaverDB.toggles.groundTargetMode == v)
      info.func = function()
        SkillWeaverDB.toggles.groundTargetMode = v
        SW.Engine:RefreshAll("ground_mode")
      end
      UIDropDownMenu_AddButton(info)
    end

    info = UIDropDownMenu_CreateInfo()
    info.text = "Reload UI"
    info.notCheckable = true
    info.func = ReloadUI
    UIDropDownMenu_AddButton(info)
  end

  EasyMenu(init, menuFrame, anchor, 0, 0, "MENU")
end
